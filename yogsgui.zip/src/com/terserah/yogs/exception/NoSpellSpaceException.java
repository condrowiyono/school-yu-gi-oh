package com.terserah.yogs.exception;

public class NoSpellSpaceException extends NoSpaceException {
	
}
