package com.terserah.yogs.exception;

public class NoMonsterSpaceException extends NoSpaceException{

}
