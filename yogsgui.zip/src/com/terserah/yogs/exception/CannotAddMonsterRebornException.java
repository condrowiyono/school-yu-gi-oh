package com.terserah.yogs.exception;

public class CannotAddMonsterRebornException extends CannotAddSpellException {

	public CannotAddMonsterRebornException() {
		super("Cannot add this card, there are no monsters in any graveyard!!");
		// TODO Auto-generated constructor stub
	}

}
