package com.terserah.yogs.exception;

public class CannotAddSpellException extends RuntimeException{

	public CannotAddSpellException(String m) {
		super(m);
	}

	

}
