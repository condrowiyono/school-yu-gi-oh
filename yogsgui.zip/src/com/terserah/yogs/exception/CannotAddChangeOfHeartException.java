package com.terserah.yogs.exception;

public class CannotAddChangeOfHeartException extends CannotAddSpellException {

	public CannotAddChangeOfHeartException() {
		super("Cannot add this card, your opponent has no monsters in the monster area!");
		// TODO Auto-generated constructor stub
	}

}
