package com.terserah.yogs.exception;

public class CannotAddMagePowerException extends CannotAddSpellException {

	public CannotAddMagePowerException() {
		super("Cannot add this card, there are no monsters on the field!");
		// TODO Auto-generated constructor stub
	}

}
