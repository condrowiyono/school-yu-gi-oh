package com.terserah.yogs.exception;

public class MissingFieldException extends UnexpectedFormatException {

	public MissingFieldException(String sourceFile, int sourceLine) {
		super(sourceFile, sourceLine);
		
	}
	
	
	

}
