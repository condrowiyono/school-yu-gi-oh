package com.terserah.yogs.cards;

abstract public class Load {

	
}
