package com.terserah.yogs.cards;

public enum Mode {
	ATTACK, DEFENSE 
}
 