package com.terserah.yogs.cards;

public enum Location {
	DECK, HAND, FIELD, GRAVEYARD
}