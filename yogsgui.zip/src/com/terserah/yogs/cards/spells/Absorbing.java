package com.terserah.yogs.cards.spells;

public interface Absorbing {

}
