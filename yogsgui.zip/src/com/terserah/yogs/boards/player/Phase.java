package com.terserah.yogs.boards.player;

public enum Phase { 
	MAIN1, BATTLE, MAIN2
}