package com.terserah.yogs.menu.gui;

import java.awt.Dimension;

import javax.swing.JButton;

public class CardButton extends JButton{
	public CardButton(){
		super();
		this.setPreferredSize(new Dimension(68,100));
	}
}
